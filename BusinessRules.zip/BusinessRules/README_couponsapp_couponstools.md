# CouponIQ README

This document describes the two modules: `couponsapp.py` and `couponstools.py` from the CouponIQ Business Rule Engine.

## 1. Overview

- `couponsapp.py`: Streamlit frontend for uploading coupon data ZIP archives, generating business rule documents, and AI chat interactions.
- `couponstools.py`: backend toolset providing coupon data processing plus LLM tool functions used by the app.

---

## 2. Dependencies

- Python 3.8+
- streamlit
- pandas
- python-docx
- langchain-core
- langgraph
- langchain-nvidia-ai-endpoints
- requests
- beautifulsoup4
- sqlite3 (standard library)

Use `pip install -r requirements.txt` (project root).

---

## 3. Environment Setup

1. Create and activate venv:

   ```powershell
   python -m venv .venv
   .venv\Scripts\Activate.ps1
   ```

2. Install requirements:

   ```powershell
   pip install -r requirements.txt
   ```

3. Set NVIDIA key:

   ```powershell
   setx NVIDIA_API_KEY "<your_api_key>"
   ```

4. Launch app:

   ```powershell
   streamlit run couponsapp.py
   ```

---

## 4. couponstools.py API

### 4.1 LangGraph + LLM setup

- `llm`: `ChatNVIDIA` instance using model `moonshotai/kimi-k2-instruct-0905`.
- `checkpointer`: SQLite state store at `chatbot.db`.

### 4.2 Tools (decorated with `@tool`)

- `summarize_code(files_dict, max_chars=80000)`
  - Creates a text summary from in-memory code or CSV file text map.

- `read_csv_tables(repo_path: str)`
  - Walks folder structure and reads all `.csv` files into preview text boxes.

- `read_file(file_path: str)`
  - Returns full file content (success/error dict).

- `generate_coupon_row_summary_doc(csv_folder: str)`
  - Finds coupon CSV (`*coupon*.csv`), reads into DataFrame, categorizes rows, and produces DOCX file at `{csv_folder}/coupon_llm_summary.docx`.
  - Uses `_categorize_coupons` for business categories:
    - Active
    - Expired
    - BOGO/free-item
    - High-value
    - Other

### 4.3 Workflow elements

- `tools`: list of tool functions.
- `llm_with_tools`: LLM bound to tools for plan-based execution.
- `ChatState`, `chat_mode`, `ToolNode`, `StateGraph`, `chatbot`: LangGraph graph to support AI conversation + tools.
- `retrieve_all_threads()`: list persisted thread IDs from SQLite.

---

## 5. couponsapp.py flow

### 5.1 UI sections

- Sidebar:
  - ZIP uploader (`.zip`)
  - `Extract & Load Files`
  - `Generate Business Rules`
  - Download DOCX
  - `Start New Chat`
  - Recent sessions list

- Main area:
  - Metrics (chat sessions, CSV files loaded, report state)
  - Upload guidance and coupon dataset summary
  - Chat conversation panel with user/assistant message area

### 5.2 Key interactions

1. Upload ZIP archive containing coupon CSV(s).
2. Click **Extract & Load Files**:
   - Extracts into a temp directory
   - Calls `read_csv_tables` (couponstools) to parse CSVs
   - Saves file preview map in session state
3. Click **Generate Business Rules**:
   - Runs `generate_coupon_row_summary_doc(csv_folder)`
   - Creates DOCX with categorized coupon analysis and LLM-generated text
   - Exposes a download button for `coupon_business_rules.docx`
4. Chat:
   - Chat messages are saved across sessions via SQLite
   - You can ask coupon-specific questions (expired vouchers, high-discount rules, etc.)

### 5.3 Helpful prompts shown in UI

- "List all expired coupons"
- "What are the high-value discount rules?"
- "Summarize active coupon policy"

---

## 6. Developer notes

- This app reuses dataset categorization code from `couponstools._categorize_coupons`.
- `couponsapp.py` has extensive CSS controls for dark UI + better layout.
- For offline testing, use smaller CSVs and avoid LLM if no API key is available (the code may still run but will fail LLM calls gracefully). 

---

## 7. Running tests (manual)

1. Put a ZIP containing `coupons_*.csv` in a local folder.
2. Run the app and verify that >0 CSVs are loaded.
3. Generate rules doc and confirm the DOCX exists in temp path.

---

## 8. Troubleshooting

- If no coupon CSV found, ensure file name has `coupon` in it.
- If DOCX generation fails, inspect console for LLM timeout or API key errors.
- If chat fails, confirm `chatbot.db` is writable by the current user.
