from langgraph.graph import StateGraph, START, END
import zipfile
from pathlib import Path
from io import BytesIO
from typing import TypedDict, Annotated, List, Dict
from langchain_core.messages import BaseMessage, HumanMessage
from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langgraph.graph.message import add_messages
from langgraph.checkpoint.sqlite import SqliteSaver
from langchain_core.tools import tool
from langgraph.prebuilt import ToolNode, tools_condition
import os
from datetime import datetime
import pandas as pd
import json
import sqlite3
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
import uuid, re, tempfile




llm =    ChatNVIDIA(
  model="moonshotai/kimi-k2-instruct-0905",
  api_key=os.getenv("NVIDIA_API_KEY"),
  temperature=0.6,
  top_p=0.7,
  max_completion_tokens=8096,
)
conn = sqlite3.connect(database='chatbot.db', check_same_thread=False)
checkpointer = SqliteSaver(conn=conn)



@tool
def summarize_code(files_dict, max_chars=80000):
    """Summarizes CSV files from a loaded files dictionary for chat context."""
    summary_parts = []
    total_chars = 0

    for fpath, content in files_dict.items():
        if total_chars >= max_chars:
            break
        if len(content) > 3000:
            content = content[:2000] + "\n... [TRUNCATED] ..."
        header = f"\n{'='*60}\nFILE: {fpath}\n{'='*60}\n"
        chunk = header + content
        if total_chars + len(chunk) <= max_chars:
            summary_parts.append(chunk)
            total_chars += len(chunk)

    return "\n".join(summary_parts)




@tool
def read_csv_tables(repo_path: str):
    """
    Reads all CSV files from a directory and converts them
    into structured text for LLM analysis.
    """
    collected = {}

    for root, dirs, files in os.walk(repo_path):
        for file in files:

            if file.lower().endswith(".csv"):

                fpath = os.path.join(root, file)

                try:
                    df = pd.read_csv(fpath)

                    preview = df.head(20).to_string(index=False)

                    text = f"""
TABLE NAME: {file}

COLUMNS:
{", ".join(df.columns)}

TOTAL ROWS:
{len(df)}

SAMPLE DATA:
{preview}
"""

                    collected[fpath] = text

                except Exception as e:
                    collected[fpath] = f"Error reading CSV {file}: {str(e)}"

    return {"files": collected}

@tool
def read_file(file_path: str):
    """This function is used to read all the file content of this computer and it opens the file in read mode"""
    if not os.path.exists(file_path):
        return {"status": "error", "message": f"File not found: {file_path}"}
    with open(file_path, "r", encoding="utf-8") as file:
        content = file.read()
    return {"status": "success", "file_content": content}



def _categorize_coupons(df: pd.DataFrame) -> dict:
    """
    Categorize coupon rows into logical business groups.
    Returns a dict mapping category label -> DataFrame subset.
    """
    categories = {}
    cols_lower = {c: c.lower() for c in df.columns}

    # Helper: find column by keyword
    def find_col(*keywords):
        for col, col_l in cols_lower.items():
            if any(k in col_l for k in keywords):
                return col
        return None

    status_col   = find_col("status", "active", "state")
    type_col     = find_col("type", "coupon_type", "discount_type")
    expiry_col   = find_col("expir", "expire", "end_date", "valid_until")
    discount_col = find_col("discount", "amount", "value", "percent")

    used = set()

    # 1. Active coupons
    if status_col:
        mask = df[status_col].astype(str).str.lower().isin(["active", "1", "true", "yes", "enabled"])
        subset = df[mask]
        if not subset.empty:
            categories["🟢 Active Coupons"] = subset
            used.update(subset.index)

    # 2. Expired coupons
    if expiry_col:
        try:
            exp_series = pd.to_datetime(df[expiry_col], errors="coerce")
            mask = exp_series < pd.Timestamp.now()
            subset = df[mask & ~df.index.isin(used)]
            if not subset.empty:
                categories["🔴 Expired Coupons"] = subset
                used.update(subset.index)
        except Exception:
            pass

    # 3. BOGO / free-item coupons
    if type_col:
        mask = df[type_col].astype(str).str.lower().str.contains("bogo|buy.one|free", na=False)
        subset = df[mask & ~df.index.isin(used)]
        if not subset.empty:
            categories["🎁 BOGO / Free-Item Coupons"] = subset
            used.update(subset.index)

    # 4. High-value discount coupons (top 25% by discount amount)
    if discount_col:
        try:
            nums = pd.to_numeric(df[discount_col], errors="coerce")
            threshold = nums.quantile(0.75)
            mask = nums >= threshold
            subset = df[mask & ~df.index.isin(used)]
            if not subset.empty:
                categories[f"💎 High-Value Discounts (≥{threshold:.0f})"] = subset
                used.update(subset.index)
        except Exception:
            pass

    # 5. Everything else
    remaining = df[~df.index.isin(used)]
    if not remaining.empty:
        categories["📦 Other Coupons"] = remaining

    # If no categorization was possible, fall back to single group
    if not categories:
        categories["📋 All Coupons"] = df

    return categories


def _add_category_heading(doc, title: str, count: int):
    """Add a styled category heading with count."""
    para = doc.add_paragraph()
    para.paragraph_format.space_before = Pt(14)
    para.paragraph_format.space_after  = Pt(4)
    run = para.add_run(f"{title}  [{count} records]")
    run.bold = True
    run.font.size = Pt(14)
    run.font.color.rgb = RGBColor(0x4F, 0x46, 0xE5)   # indigo-600
    doc.add_paragraph("─" * 72).paragraph_format.space_after = Pt(8)


@tool
def generate_coupon_row_summary_doc(csv_folder: str) -> str:
    """
    Generate coupon summaries using LLM in batches to avoid timeout.
    Records are first categorized into business-meaningful groups,
    then each group is documented separately in the output DOCX.
    """

    coupon_file = None

    for f in os.listdir(csv_folder):
        if "coupon" in f.lower() and f.endswith(".csv"):
            coupon_file = os.path.join(csv_folder, f)
            break

    if not coupon_file:
        return "Coupons CSV not found"

    df = pd.read_csv(coupon_file)

    doc = Document()

    # ── Title page ──────────────────────────────────────────────────────
    title_para = doc.add_heading("Coupons Business Rules Report", level=0)
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER

    meta = doc.add_paragraph()
    meta.alignment = WD_ALIGN_PARAGRAPH.CENTER
    meta.paragraph_format.space_after = Pt(18)
    meta.add_run(
        f"Generated: {datetime.now().strftime('%B %d, %Y %H:%M')}  •  "
        f"Total Records: {len(df)}"
    ).font.color.rgb = RGBColor(0x6B, 0x75, 0x85)

    doc.add_paragraph()   # spacer

    # ── Categorize ──────────────────────────────────────────────────────
    categories = _categorize_coupons(df)

    # ── TOC-style summary ───────────────────────────────────────────────
    toc_heading = doc.add_heading("Categories Overview", level=1)
    for cat_name, cat_df in categories.items():
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3)
        p.paragraph_format.space_after = Pt(4)
        p.add_run(f"{cat_name}").bold = True
        p.add_run(f"  —  {len(cat_df)} record(s)")
    doc.add_paragraph()   # spacer

    batch_size = 20

    # ── Per-category sections ────────────────────────────────────────────
    for cat_name, cat_df in categories.items():
        _add_category_heading(doc, cat_name, len(cat_df))

        for start in range(0, len(cat_df), batch_size):
            batch = cat_df.iloc[start:start + batch_size]
            rows_json = batch.to_dict(orient="records")

            prompt = f"""
You are documenting an ecommerce coupons dataset.

Category: {cat_name}
Below are rows from this category of the coupons table.

{json.dumps(rows_json, indent=2)}

For EACH row generate a detailed business explanation covering:
- What the coupon offers
- Who it targets
- Key restrictions or conditions
- Business purpose / intent
"""

            response = llm.invoke(prompt)
            text_output = response.content if hasattr(response, "content") else str(response)
            doc.add_paragraph(text_output)

        doc.add_paragraph()   # spacer between categories

    output_path = os.path.join(csv_folder, "coupon_llm_summary.docx")
    doc.save(output_path)

    return {
        "status": "success",
        "document_path": output_path
    }

tools = [
    summarize_code,
    read_csv_tables,
    read_file,
    generate_coupon_row_summary_doc,
]

llm_with_tools = llm.bind_tools(tools)


class ChatState(TypedDict):
    messages: Annotated[list[BaseMessage], add_messages]

def chat_mode(state: ChatState):
    response = llm_with_tools.invoke(state["messages"])
    return {"messages": response}

tool_node = ToolNode(tools)

graph = StateGraph(ChatState)
graph.add_node("chat_mode", chat_mode)
graph.add_node("tools", tool_node)

graph.add_edge(START, "chat_mode")
graph.add_conditional_edges("chat_mode", tools_condition)
graph.add_edge("tools", "chat_mode")

chatbot = graph.compile(checkpointer=checkpointer)

def retrieve_all_threads():
    all_threads = set()
    for checkpoint in checkpointer.list(None):
        all_threads.add(checkpoint.config['configurable']['thread_id'])

    return list(all_threads)
