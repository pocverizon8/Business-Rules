from dataclasses import fields
from annotated_types import doc
import streamlit as st
from csvalltools import (
    generate_coupon_row_summary_doc, summarize_code, retrieve_all_threads,
    chatbot, read_csv_tables, generate_beautiful_doc, render_mermaid_to_png
)
from langchain_core.messages import HumanMessage, AIMessage, ToolMessage, SystemMessage
import uuid, tempfile, os, io, re, json, html, zipfile, time
from requests.exceptions import ChunkedEncodingError, Timeout, ConnectionError
from langchain_nvidia_ai_endpoints import ChatNVIDIA
from langgraph.graph import StateGraph, START, END
from typing import List, TypedDict
from bs4 import BeautifulSoup

# ─── Page config ──────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="CouponIQ — Business Rule Engine",
    page_icon="🎟️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── CSS ──────────────────────────────────────────────────────────────────────
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');

:root {
    --white:        #ffffff;
    --gray-50:      #f8f9fc;
    --gray-100:     #f1f3f7;
    --gray-200:     #e4e8f0;
    --gray-300:     #cbd2de;
    --gray-400:     #9aa3b2;
    --gray-500:     #6b7585;
    --gray-700:     #374151;
    --gray-900:     #111827;
    --indigo-50:    #eef2ff;
    --indigo-100:   #e0e7ff;
    --indigo-400:   #818cf8;
    --indigo-500:   #6366f1;
    --indigo-600:   #4f46e5;
    --indigo-700:   #4338ca;
    --violet-500:   #8b5cf6;
    --emerald-50:   #ecfdf5;
    --emerald-500:  #10b981;
    --emerald-600:  #059669;
    --shadow-sm: 0 1px 3px rgba(0,0,0,.08), 0 1px 2px rgba(0,0,0,.04);
    --shadow-md: 0 4px 12px rgba(0,0,0,.10), 0 2px 4px rgba(0,0,0,.05);
    --font: 'Inter', -apple-system, sans-serif;
    --mono: 'JetBrains Mono', monospace;
}

html, body, [class*="css"] {
    font-family: var(--font) !important;
    color: var(--gray-900) !important;
    background-color: var(--gray-50) !important;
    -webkit-font-smoothing: antialiased;
}

#MainMenu, footer, header { visibility: hidden !important; }
.block-container { padding: 1.5rem 2rem 3rem !important; max-width: 1360px !important; }

/* ── Sidebar ── */
[data-testid="stSidebar"] {
    background: var(--white) !important;
    border-right: 1px solid var(--gray-200) !important;
    box-shadow: 2px 0 12px rgba(0,0,0,.04) !important;
}
[data-testid="stSidebar"] > div:first-child { padding-top: 0 !important; }
[data-testid="stSidebarContent"] { padding: 0 !important; }

.sb-brand {
    background: linear-gradient(135deg, var(--indigo-600) 0%, var(--violet-500) 100%);
    padding: 20px 18px 16px;
}
.sb-brand-row { display: flex; align-items: center; gap: 10px; margin-bottom: 3px; }
.sb-brand-icon {
    width: 36px; height: 36px; border-radius: 9px;
    background: rgba(255,255,255,0.22);
    display: flex; align-items: center; justify-content: center; font-size: 18px;
}
.sb-brand-name { font-size: 15px; font-weight: 700; color: #fff; letter-spacing: -.3px; }
.sb-brand-sub  { font-size: 11px; color: rgba(255,255,255,.65); }
.sb-sec { padding: 14px 16px 6px; font-size: 10px; font-weight: 600; letter-spacing: .9px; text-transform: uppercase; color: var(--gray-400); }
.sb-stat {
    display: flex; align-items: center; justify-content: space-between;
    margin: 0 12px 6px; background: var(--gray-50); border: 1px solid var(--gray-200);
    border-radius: 10px; padding: 9px 12px; font-size: 12px;
}
.sb-stat .sl { color: var(--gray-500); }
.sb-stat .sv { font-weight: 700; color: var(--indigo-600); font-family: var(--mono); font-size: 13px; }

/* ── Buttons ── */
.stButton > button {
    background: var(--white) !important; color: var(--gray-700) !important;
    border: 1px solid var(--gray-300) !important; border-radius: 8px !important;
    font-family: var(--font) !important; font-size: 13px !important;
    font-weight: 500 !important; padding: 9px 16px !important;
    width: 100% !important; transition: all .15s ease !important;
    box-shadow: var(--shadow-sm) !important;
}
.stButton > button:hover {
    background: var(--gray-50) !important; border-color: var(--gray-400) !important;
    color: var(--gray-900) !important; box-shadow: var(--shadow-md) !important;
}

/* Primary buttons */
div[data-testid="stButton"]:has(button[key="gen_doc"]) button,
div[data-testid="stButton"]:has(button[key="extract_btn"]) button {
    background: linear-gradient(135deg, var(--indigo-600), var(--violet-500)) !important;
    color: #fff !important; border: none !important; font-weight: 600 !important;
    box-shadow: 0 4px 14px rgba(99,102,241,.35) !important;
}
div[data-testid="stButton"]:has(button[key="gen_doc"]) button:hover,
div[data-testid="stButton"]:has(button[key="extract_btn"]) button:hover {
    box-shadow: 0 6px 20px rgba(99,102,241,.45) !important; transform: translateY(-1px) !important;
}

.stDownloadButton > button {
    background: var(--emerald-50) !important; color: var(--emerald-600) !important;
    border: 1px solid #a7f3d0 !important; border-radius: 8px !important;
    font-family: var(--font) !important; font-size: 13px !important;
    font-weight: 600 !important; width: 100% !important;
}
.stDownloadButton > button:hover { background: #d1fae5 !important; border-color: var(--emerald-500) !important; }

/* ── File uploader ── */
[data-testid="stFileUploader"] {
    background: var(--white) !important;
    border: 2px dashed var(--gray-300) !important;
    border-radius: 12px !important;
}
[data-testid="stFileUploader"]:hover { border-color: var(--indigo-400) !important; }
[data-testid="stFileUploader"] label,
[data-testid="stFileUploaderDropzoneInstructions"] * {
    color: var(--gray-500) !important; font-size: 12px !important; font-family: var(--font) !important;
}

/* ══════════════════════════════
   CHAT INPUT — THE KEY FIX
   Force white background + dark text
   so users can see what they type
══════════════════════════════ */
[data-testid="stChatInput"] {
    background: var(--white) !important;
    border: 2px solid var(--gray-200) !important;
    border-radius: 14px !important;
    box-shadow: var(--shadow-sm) !important;
}
[data-testid="stChatInput"]:focus-within {
    border-color: var(--indigo-400) !important;
    box-shadow: 0 0 0 3px rgba(99,102,241,.12) !important;
}
/* textarea itself */
[data-testid="stChatInput"] textarea {
    background: var(--white) !important;
    color: var(--gray-900) !important;
    font-family: var(--font) !important;
    font-size: 14px !important;
    line-height: 1.6 !important;
    caret-color: var(--indigo-600) !important;
}
[data-testid="stChatInput"] textarea::placeholder { color: var(--gray-400) !important; }
[data-testid="stChatInputSubmitButton"] > button {
    background: var(--indigo-600) !important; border-radius: 9px !important; color: #fff !important;
}
[data-testid="stChatInputSubmitButton"] > button:hover { background: var(--indigo-700) !important; }

/* ══════════════════════════════
   CHAT MESSAGES — fully readable
══════════════════════════════ */
[data-testid="stChatMessage"] {
    background: var(--white) !important;
    border: 1px solid var(--gray-200) !important;
    border-radius: 14px !important;
    padding: 14px 18px !important;
    margin-bottom: 10px !important;
    box-shadow: var(--shadow-sm) !important;
}
/* Tint user messages */
[data-testid="stChatMessage"]:has([data-testid="chatAvatarIcon-user"]) {
    background: var(--indigo-50) !important;
    border-color: var(--indigo-100) !important;
}
/* All text dark and readable */
[data-testid="stChatMessage"] p,
[data-testid="stChatMessage"] li,
[data-testid="stChatMessage"] span:not([data-testid]),
[data-testid="stChatMessage"] div:not([data-testid]) {
    color: var(--gray-900) !important;
    font-size: 14px !important;
    line-height: 1.75 !important;
}
[data-testid="stChatMessage"] strong { color: var(--gray-900) !important; font-weight: 600 !important; }
[data-testid="stChatMessage"] em     { color: var(--gray-600) !important; }
[data-testid="stChatMessage"] code {
    background: var(--gray-100) !important; color: var(--indigo-700) !important;
    font-family: var(--mono) !important; font-size: 12px !important;
    padding: 2px 6px; border-radius: 5px; border: 1px solid var(--gray-200);
}
[data-testid="stChatMessage"] pre {
    background: #1e293b !important; color: #e2e8f0 !important;
    border-radius: 10px !important; padding: 14px 18px !important; font-size: 12px !important;
    border: none !important;
}
/* Avatar */
[data-testid="chatAvatarIcon-user"],
[data-testid="chatAvatarIcon-assistant"] {
    background: var(--indigo-600) !important; color: #fff !important;
}

/* ── Spinner / Status ── */
[data-testid="stSpinner"] p { color: var(--gray-500) !important; font-size: 13px !important; }
[data-testid="stStatusWidget"] {
    background: var(--white) !important; border: 1px solid var(--gray-200) !important;
    border-radius: 10px !important; color: var(--gray-700) !important; font-size: 13px !important;
}

/* ── Alerts ── */
[data-testid="stAlert"] { border-radius: 10px !important; font-size: 13px !important; font-family: var(--font) !important; }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 5px; height: 5px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: var(--gray-300); border-radius: 10px; }
::-webkit-scrollbar-thumb:hover { background: var(--gray-400); }
hr { border: none !important; border-top: 1px solid var(--gray-200) !important; margin: 10px 0 !important; }

/* ═══════════════════════
   PAGE LAYOUT COMPONENTS
═══════════════════════ */
.topbar {
    display: flex; align-items: center; justify-content: space-between;
    padding: 14px 0 20px; border-bottom: 1px solid var(--gray-200); margin-bottom: 22px;
}
.tb-left { display: flex; align-items: center; gap: 14px; }
.tb-logo {
    width: 40px; height: 40px; border-radius: 11px;
    background: linear-gradient(135deg, var(--indigo-600), var(--violet-500));
    display: flex; align-items: center; justify-content: center;
    font-size: 20px; box-shadow: 0 4px 14px rgba(99,102,241,.3);
}
.tb-title  { font-size: 19px; font-weight: 700; color: var(--gray-900); letter-spacing: -.5px; }
.tb-sub    { font-size: 12px; color: var(--gray-400); margin-top: 1px; }
.tb-badge  {
    display: inline-flex; align-items: center; gap: 7px;
    background: var(--emerald-50); border: 1px solid #a7f3d0;
    border-radius: 20px; padding: 5px 14px;
    font-size: 12px; font-weight: 500; color: var(--emerald-600);
}
.live-dot {
    width: 8px; height: 8px; border-radius: 50%; background: var(--emerald-500);
    animation: blink 2s infinite;
}
@keyframes blink {
    0%,100% { opacity:1; box-shadow: 0 0 0 0 rgba(16,185,129,.4); }
    50%      { opacity:.6; box-shadow: 0 0 0 5px rgba(16,185,129,0); }
}

.metric-grid {
    display: grid; grid-template-columns: repeat(3,1fr); gap: 14px; margin-bottom: 18px;
}
.mc {
    background: var(--white); border: 1px solid var(--gray-200);
    border-radius: 14px; padding: 16px 20px;
    box-shadow: var(--shadow-sm); position: relative; overflow: hidden;
}
.mc::before {
    content:''; position:absolute; top:0; left:0; width:4px; height:100%;
    background: linear-gradient(180deg, var(--indigo-500), var(--violet-500));
}
.mc-lbl { font-size:11px; font-weight:600; text-transform:uppercase; letter-spacing:.6px; color:var(--gray-400); margin-bottom:5px; }
.mc-val { font-size:32px; font-weight:700; color:var(--gray-900); font-family:var(--mono); letter-spacing:-1.5px; line-height:1; }
.mc-sub { font-size:11px; color:var(--gray-400); margin-top:4px; }

.pipeline {
    display:flex; align-items:center; background:var(--white);
    border:1px solid var(--gray-200); border-radius:14px;
    padding:10px 18px; margin-bottom:20px; gap:0;
    box-shadow:var(--shadow-sm); overflow-x:auto;
}
.ps {
    display:flex; align-items:center; gap:7px;
    padding:7px 14px; border-radius:9px;
    font-size:12px; font-weight:500; color:var(--gray-400); white-space:nowrap;
}
.ps.done   { color:var(--gray-600); }
.ps.active { background:var(--indigo-50); color:var(--indigo-600); font-weight:600; }
.ps-n {
    width:21px; height:21px; border-radius:50%;
    background:var(--gray-200); color:var(--gray-500);
    display:flex; align-items:center; justify-content:center;
    font-size:10px; font-weight:700; flex-shrink:0;
}
.ps.done   .ps-n { background:var(--emerald-500); color:#fff; }
.ps.active .ps-n { background:var(--indigo-600);  color:#fff; }
.pa { color:var(--gray-300); padding:0 4px; font-size:14px; flex-shrink:0; }

.sec-hd {
    font-size:12px; font-weight:600; color:var(--gray-500);
    text-transform:uppercase; letter-spacing:.7px;
    margin-bottom:12px; padding-bottom:8px; border-bottom:1px solid var(--gray-200);
}

.empty-chat {
    text-align:center; padding:52px 24px;
    background:var(--gray-50); border:2px dashed var(--gray-200); border-radius:16px;
}
.ec-icon { font-size:38px; margin-bottom:12px; }
.ec-title { font-size:17px; font-weight:600; color:var(--gray-700); margin-bottom:6px; }
.ec-sub { font-size:13px; color:var(--gray-400); line-height:1.6; max-width:340px; margin:0 auto 14px; }
.ec-chip {
    display:inline-block; background:var(--indigo-50); color:var(--indigo-600);
    border:1px solid var(--indigo-100); border-radius:20px;
    padding:5px 14px; font-size:12px; font-weight:500; margin:3px;
}

.info-card {
    background:var(--white); border:1px solid var(--gray-200);
    border-radius:14px; padding:18px 16px;
    box-shadow:var(--shadow-sm); margin-bottom:12px;
}
.how-step {
    display:flex; gap:12px; align-items:flex-start;
    padding:11px 0; border-bottom:1px solid var(--gray-100);
}
.how-step:last-of-type { border-bottom:none; }
.hs-num {
    width:28px; height:28px; border-radius:50%; flex-shrink:0;
    background:linear-gradient(135deg,var(--indigo-500),var(--violet-500));
    display:flex; align-items:center; justify-content:center;
    font-size:11px; font-weight:700; color:#fff;
    box-shadow:0 2px 6px rgba(99,102,241,.3);
}
.hs-t { font-size:13px; font-weight:600; color:var(--gray-800); margin-bottom:2px; }
.hs-d { font-size:11px; color:var(--gray-400); line-height:1.5; }
.tag {
    display:inline-block; background:var(--gray-100); color:var(--gray-600);
    border:1px solid var(--gray-200); border-radius:6px;
    padding:3px 8px; font-family:var(--mono); font-size:10px; font-weight:500; margin:3px 2px;
}
.tip-card {
    background:var(--indigo-50); border:1px solid var(--indigo-100);
    border-radius:14px; padding:14px 16px; margin-top:0;
}
.tip-hd { font-size:12px; font-weight:600; color:var(--indigo-700); margin-bottom:8px; }
.tip-txt { font-size:11px; color:var(--indigo-600); line-height:1.75; }

/* ── Category badges & record cards ── */
.cat-badge {
    display:inline-flex; align-items:center; gap:5px;
    padding:3px 10px; border-radius:20px; font-size:11px; font-weight:600;
    margin:2px; border:1px solid transparent;
}
.cat-active   { background:#dcfce7; color:#166534; border-color:#86efac; }
.cat-expired  { background:#fee2e2; color:#991b1b; border-color:#fca5a5; }
.cat-discount { background:#ede9fe; color:#5b21b6; border-color:#c4b5fd; }
.cat-bogo     { background:#fef3c7; color:#92400e; border-color:#fcd34d; }
.cat-other    { background:#f1f5f9; color:#475569; border-color:#cbd5e1; }

.cat-section-hd {
    font-size:13px; font-weight:700; color:var(--gray-800);
    padding:10px 0 6px; border-bottom:2px solid var(--gray-200);
    margin:16px 0 10px; letter-spacing:-.2px;
}
.cat-count-pill {
    display:inline-flex; align-items:center; justify-content:center;
    background:var(--indigo-600); color:#fff;
    border-radius:12px; padding:1px 8px; font-size:10px; font-weight:700;
    margin-left:7px; vertical-align:middle;
}
</style>
""", unsafe_allow_html=True)
from dotenv import load_dotenv
    
load_dotenv()
# ─── LLMs ─────────────────────────────────────────────────────────────────────
llm = ChatNVIDIA(
    model="qwen/qwen3-next-80b-a3b-instruct",
    api_key=os.getenv("NVIDIA_API_KEY"),
    temperature=0.6, top_p=0.7, 
    max_completion_tokens=8096,
)
llm2 = ChatNVIDIA(
    model="moonshotai/kimi-k2-thinking",
    api_key=os.getenv("NVIDIA_API_KEY"),
    temperature=0.6, top_p=0.7, 
    max_completion_tokens=4096,
)

# ─── Helpers ──────────────────────────────────────────────────────────────────
def invoke_llm_with_retry(llm_obj, prompt, max_retries=3, base_wait=2):
    last_error = None
    for attempt in range(max_retries):
        try:
            return llm_obj.invoke(prompt)
        except (Timeout, ConnectionError, Exception) as e:
            last_error = e
            if "504" in str(e) or "timeout" in str(e).lower() or "gateway" in str(e).lower():
                if attempt < max_retries - 1:
                    time.sleep(base_wait * (2 ** attempt))
                else:
                    st.error("API failed after 3 attempts.")
                    raise
            else:
                raise
    raise last_error

def generate_thread_id():  return uuid.uuid4()
def add_thread(tid):
    if tid not in st.session_state["chat_threads"]:
        st.session_state["chat_threads"].append(tid)

def reset_chat():
    tid = generate_thread_id()
    st.session_state.update({"thread_id": tid, "message_history": []})
    add_thread(tid)

def load_conversation(tid):
    state = chatbot.get_state(config={"configurable": {"thread_id": tid}})
    return state.values.get("messages", [])

# ─── Session state ─────────────────────────────────────────────────────────────
for k, v in {
    "extract_dir": None, "generated_doc": None, "repo_summary_for_chat": None,
    "message_history": [], "thread_id": generate_thread_id(),
    "chat_threads": retrieve_all_threads(), "extracted_code": None,
    "tool_outputs": {}, "docx_ready": False, "docx_path": None,
}.items():
    if k not in st.session_state:
        st.session_state[k] = v

add_thread(st.session_state["thread_id"])

# ══════════════════════════════════════════════════════════════════════════════
# SIDEBAR
# ══════════════════════════════════════════════════════════════════════════════
with st.sidebar:
    st.markdown("""
    <div class="sb-brand">
        <div class="sb-brand-row">
            <div class="sb-brand-icon">🎟️</div>
            <div>
                <div class="sb-brand-name">CouponIQ</div>
            </div>
        </div>
        <div class="sb-brand-sub">Business Rule Generation Engine</div>
    </div>
    """, unsafe_allow_html=True)

    st.markdown('<div class="sb-sec">📁 Upload Repository</div>', unsafe_allow_html=True)
    uploaded_zip = st.file_uploader("ZIP file", type=["zip"], label_visibility="collapsed")

    if uploaded_zip:
        if st.button("⚡ Extract & Load Files", key="extract_btn"):
            with st.spinner("Extracting archive…"):
                extract_dir = tempfile.mkdtemp(dir=".")
                with zipfile.ZipFile(uploaded_zip, "r") as zf:
                    zf.extractall(extract_dir)
                result    = read_csv_tables.invoke({"repo_path": extract_dir})
                all_files = result.get("files", {})
                st.session_state.update({
                    "extracted_code": all_files,
                    "extract_dir": extract_dir,
                    "repo_summary_for_chat": None,
                })
            st.success(f"✅ Loaded {len(all_files)} file(s)")

    if st.session_state["extracted_code"]:
        n = len(st.session_state["extracted_code"])
        st.markdown(f"""
        <div class="sb-stat"><span class="sl">CSV files ready</span><span class="sv">{n}</span></div>
        """, unsafe_allow_html=True)

    st.markdown('<div class="sb-sec">⚙️ Actions</div>', unsafe_allow_html=True)

    if st.button("📄 Generate Business Rules", key="gen_doc"):
        if st.session_state.get("extract_dir"):
            with st.spinner("Analysing coupons and generating rules…"):
                try:
                    result = generate_coupon_row_summary_doc(st.session_state["extract_dir"])
                    if result["status"] == "success":
                        st.session_state.update({"docx_ready": True, "docx_path": result["document_path"]})
                        st.success("✅ Document ready!")
                    else:
                        st.error(f"Error: {result['message']}")
                except Exception as e:
                    st.error(f"Error: {e}")
        else:
            st.warning("Upload and extract a ZIP file first.")

    if st.session_state["docx_ready"] and st.session_state["docx_path"]:
        with open(st.session_state["docx_path"], "rb") as f:
            st.download_button(
                "⬇️ Download Business Rules DOCX", data=f,
                file_name="coupon_business_rules.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                key="dl_docx",
            )

    if st.button("🔄 Start New Chat", key="new_chat"):
        reset_chat()
        st.rerun()

    threads = st.session_state["chat_threads"]
    if threads:
        st.markdown('<div class="sb-sec">💬 Recent Sessions</div>', unsafe_allow_html=True)
        for tid in reversed(threads[-8:]):
            short    = str(tid)[:8] + "…"
            is_active = str(tid) == str(st.session_state["thread_id"])
            if st.button(f"{'●' if is_active else '○'}  {short}", key=f"t_{tid}"):
                st.session_state["thread_id"] = tid
                msgs = load_conversation(tid)
                st.session_state["message_history"] = [
                    {"role": "user" if isinstance(m, HumanMessage) else "assistant",
                     "content": m.content}
                    for m in msgs
                ]
                st.rerun()

# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════
n_files   = len(st.session_state["extracted_code"]) if st.session_state["extracted_code"] else 0
n_threads = len(st.session_state["chat_threads"])

st.markdown(f"""
<div class="topbar">
    <div class="tb-left">
        <div class="tb-logo">🎟️</div>
        <div>
            <div class="tb-title">Business Rule Engine</div>
            <div class="tb-sub">AI-powered documentation · LangGraph · NVIDIA Qwen3</div>
        </div>
    </div>
    <div class="tb-badge"><div class="live-dot"></div> Agent Ready</div>
</div>
""", unsafe_allow_html=True)

st.markdown(f"""
<div class="metric-grid">
    <div class="mc"><div class="mc-lbl">Chat Sessions</div><div class="mc-val">{n_threads}</div><div class="mc-sub">persisted via SQLite</div></div>
    <div class="mc"><div class="mc-lbl">Data Loaded</div><div class="mc-val">{n_files}</div><div class="mc-sub">{"CSV file(s) ready" if n_files > 0 else "upload a ZIP to begin"}</div></div>
    <div class="mc"><div class="mc-lbl">Report</div><div class="mc-val" style="font-size:22px;line-height:1.2;padding-top:4px">{"📄" if st.session_state.get("docx_ready") else "—"}</div><div class="mc-sub">{"DOCX ready to download" if st.session_state.get("docx_ready") else "not yet generated"}</div></div>
</div>
""", unsafe_allow_html=True)

has_files = bool(st.session_state["extracted_code"])
has_doc   = st.session_state["docx_ready"]

def pipe_step(label, num, state):
    return f'<div class="ps {state}"><div class="ps-n">{num}</div>{label}</div>'

st.markdown(f"""
<div class="pipeline">
    {pipe_step("Upload ZIP",      "1", "done" if has_files else "active")}
    <span class="pa">›</span>
    {pipe_step("Extract & Scan",  "2", "done" if has_files else "")}
    <span class="pa">›</span>
    {pipe_step("Run Batch LLM",   "3", "done" if has_doc else "active" if has_files else "")}
    <span class="pa">›</span>
    {pipe_step("Download Report", "4", "active" if has_doc else "")}
</div>
""", unsafe_allow_html=True)

# ── Two-column layout ──────────────────────────────────────────────────────────
col_main, col_side = st.columns([3, 1], gap="large")

with col_main:
    st.markdown('<div class="sec-hd">💬 AI Chat Assistant</div>', unsafe_allow_html=True)

    if not st.session_state["message_history"]:
        st.markdown("""
        <div class="empty-chat">
            <div class="ec-icon">🤖</div>
            <div class="ec-title">Ask anything about your coupons</div>
            <div class="ec-sub">Upload a coupon CSV then start chatting. Try one of these:</div>
            <div>
                <span class="ec-chip">"What's the highest discount?"</span>
                <span class="ec-chip">"List all expired coupons"</span>
                <span class="ec-chip">"Summarise all business rules"</span>
            </div>
        </div>
        """, unsafe_allow_html=True)
    else:
        for msg in st.session_state["message_history"]:
            with st.chat_message(msg["role"]):
                st.markdown(msg["content"])

    # Chat input — white background, dark text, fully visible
    user_input = st.chat_input(
        "Type your question here… e.g. What is the maximum discount available?"
    )

    if user_input:
        st.session_state["message_history"].append({"role": "user", "content": user_input})
        with st.chat_message("user"):
            st.markdown(user_input)

        messages_to_send = []
        if st.session_state.get("repo_summary_for_chat") and st.session_state.get("extract_dir"):
            messages_to_send.append(SystemMessage(content=(
                "You are a helpful assistant for an e-commerce coupon dataset.\n\n"
                f"Repository summary:\n{st.session_state['repo_summary_for_chat']}\n\n"
                f"Data folder: {st.session_state['extract_dir']}"
            )))
        for m in st.session_state["message_history"][:-1]:
            messages_to_send.append(
                HumanMessage(content=m["content"]) if m["role"] == "user"
                else AIMessage(content=m["content"])
            )
        messages_to_send.append(HumanMessage(content=user_input))

        CONFIG = {
            "configurable":    {"thread_id": st.session_state["thread_id"]},
            "metadata":        {"thread_id": st.session_state["thread_id"]},
            "run_name":        "chat_turn",
            "recursion_limit": 100,
        }

        with st.chat_message("assistant"):
            status_holder = {"box": None}

            def ai_stream():
                for chunk, _ in chatbot.stream(
                    {"messages": messages_to_send}, config=CONFIG, stream_mode="messages"
                ):
                    if isinstance(chunk, ToolMessage):
                        name = getattr(chunk, "name", "tool")
                        if status_holder["box"] is None:
                            status_holder["box"] = st.status(f"🔧 Running `{name}`…", expanded=True)
                        else:
                            status_holder["box"].update(label=f"🔧 Running `{name}`…", state="running", expanded=True)
                    if isinstance(chunk, AIMessage):
                        yield chunk.content

            ai_reply = st.write_stream(ai_stream())
            if status_holder["box"]:
                status_holder["box"].update(label="✅ Done", state="complete", expanded=False)

        st.session_state["message_history"].append({"role": "assistant", "content": ai_reply})

        for fname, label, mime in [
            ("output.pdf",     "⬇️ Download PDF",        "application/pdf"),
            ("er_diagram.png", "⬇️ Download ER Diagram",  "image/png"),
        ]:
            path = os.path.join(os.getcwd(), fname)
            if fname in ai_reply and os.path.exists(path):
                with open(path, "rb") as f:
                    st.download_button(label, data=f, file_name=fname, mime=mime)

    # Build repo summary for chat
    if st.session_state["extracted_code"] and st.session_state["repo_summary_for_chat"] is None:
        with st.spinner("🔍 Building context for chat…"):
            st.session_state["repo_summary_for_chat"] = summarize_code.invoke({
                "files_dict": st.session_state["extracted_code"], "max_chars": 80000,
            })

with col_side:
    st.markdown('<div class="sec-hd">📊 Dataset Categories</div>', unsafe_allow_html=True)

    if st.session_state.get("extracted_code"):
        # Find the coupon CSV from loaded files and show live category breakdown
        import pandas as pd
        coupon_df = None
        for fpath, content in st.session_state["extracted_code"].items():
            if "coupon" in os.path.basename(fpath).lower() and fpath.endswith(".csv"):
                try:
                    coupon_df = pd.read_csv(fpath)
                except Exception:
                    pass
                break

        if coupon_df is not None:
            from csvalltools import _categorize_coupons  # reuse the same logic
            cats = _categorize_coupons(coupon_df)
            total = len(coupon_df)

            cat_colors = {
                "🟢": ("cat-active",   "#dcfce7", "#166534"),
                "🔴": ("cat-expired",  "#fee2e2", "#991b1b"),
                "🎁": ("cat-discount", "#ede9fe", "#5b21b6"),
                "💎": ("cat-bogo",     "#fef3c7", "#92400e"),
                "📦": ("cat-other",    "#f1f5f9", "#475569"),
                "📋": ("cat-other",    "#f1f5f9", "#475569"),
            }

            cards_html = ""
            for name, df_cat in cats.items():
                emoji = name[0]
                _, bg, fg = cat_colors.get(emoji, ("cat-other", "#f1f5f9", "#475569"))
                pct = round(len(df_cat) / total * 100) if total else 0
                bar_w = max(4, pct)
                cards_html += f"""
                <div class="cat-card" style="border-left:4px solid {fg};">
                    <div class="cat-card-top">
                        <span class="cat-card-name">{name}</span>
                        <span class="cat-card-count" style="color:{fg}">{len(df_cat)}</span>
                    </div>
                    <div class="cat-bar-bg">
                        <div class="cat-bar-fill" style="width:{bar_w}%;background:{fg};"></div>
                    </div>
                    <div class="cat-pct">{pct}% of {total} records</div>
                </div>
                """

            st.markdown(f"""
            <style>
            .cat-card {{
                background:#fff; border-radius:10px; padding:11px 13px;
                margin-bottom:9px; box-shadow:0 1px 4px rgba(0,0,0,.07);
                border: 1px solid #e4e8f0;
            }}
            .cat-card-top {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; }}
            .cat-card-name {{ font-size:12px; font-weight:600; color:#374151; }}
            .cat-card-count {{ font-size:18px; font-weight:700; font-family:'JetBrains Mono',monospace; }}
            .cat-bar-bg {{ background:#f1f3f7; border-radius:6px; height:5px; margin-bottom:4px; }}
            .cat-bar-fill {{ height:5px; border-radius:6px; transition:width .4s ease; }}
            .cat-pct {{ font-size:10px; color:#9aa3b2; }}
            </style>
            {cards_html}
            """, unsafe_allow_html=True)
        else:
            st.markdown("""
            <div class="tip-card">
                <div class="tip-hd">⚠️ No coupon CSV found</div>
                <div class="tip-txt">Make sure your ZIP contains a file with "coupon" in its name.</div>
            </div>
            """, unsafe_allow_html=True)
    else:
        st.markdown("""
        <div class="tip-card">
            <div class="tip-hd">💡 Quick Tips</div>
            <div class="tip-txt">
                • ZIP must contain a file with <b>"coupon"</b> in the name<br>
                • Categories are detected automatically from your data<br>
                • Chat uses the full CSV context automatically<br>
                • All sessions are saved — switch anytime from sidebar
            </div>
        </div>
        """, unsafe_allow_html=True)